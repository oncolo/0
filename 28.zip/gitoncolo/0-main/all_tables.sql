<?php
$conn = mysqli_connect('localhost','root','','school');
if($conn->connect_error){
  echo "error";
}else{
//   echo "success";
}
?>
